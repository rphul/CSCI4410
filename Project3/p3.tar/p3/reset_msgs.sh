#!/bin/bash
> msgs.txt
echo "Alice - Hello<br>" >> msgs.txt
echo "Bob - Whatever<br>" >> msgs.txt